package com.saad.map;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int LOCATION_REQ = 41;
    private WebView webView;
    private LocationManager locationManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                callback.invoke(origin, hasLocationPermission(), false);
            }
        });
        webView.addJavascriptInterface(new Bridge(), "Native");
        webView.loadUrl("file:///android_asset/index.html");
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if (hasLocationPermission()) startUpdates();
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void startUpdates() {
        if (!hasLocationPermission()) return;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 2, listener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, listener);
            Location l = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null) sendLocation(l);
        } catch (SecurityException ignored) { }
    }
    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location l) { sendLocation(l); }
    };
    private void sendLocation(Location l) {
        String js = String.format(Locale.US, "window.onNativeLocation&&window.onNativeLocation(%.7f,%.7f,%.2f,%.2f);",
                l.getLatitude(), l.getLongitude(), l.hasSpeed()?l.getSpeed():0f, l.hasAccuracy()?l.getAccuracy():-1f);
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }
    private class Bridge {
        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (hasLocationPermission()) startUpdates();
                else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
            });
        }
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == LOCATION_REQ && hasLocationPermission()) startUpdates();
        else if (webView != null) webView.evaluateJavascript("window.locationDenied&&window.locationDenied()", null);
    }
    @Override protected void onDestroy() {
        if (locationManager != null) try { locationManager.removeUpdates(listener); } catch (Exception ignored) {}
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.handleBack&&window.handleBack()", null);
        else super.onBackPressed();
    }
}
